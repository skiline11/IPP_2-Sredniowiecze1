var searchData=
[
  ['constructor_5fof_5fmain_5flist',['constructor_of_main_list',['../engine_8h.html#a121e21e0e93b33f6071d24a43ce28830',1,'engine.h']]],
  ['counter_5fof_5frounds',['counter_of_rounds',['../engine_8h.html#aa60bf4b5b108d9591140a5abfc89c5fb',1,'engine.h']]]
];
