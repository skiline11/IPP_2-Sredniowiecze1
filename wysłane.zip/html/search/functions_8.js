var searchData=
[
  ['set_5finput_5fparameters',['set_input_parameters',['../engine_8h.html#a8e474b14265a2ebbcb0c7461817214bc',1,'engine.c']]],
  ['start_5fgame',['start_game',['../engine_8h.html#a671b58f5509a3a9fa692bacccfc32cc9',1,'engine.c']]]
];
