var searchData=
[
  ['p1',['p1',['../structinput__parameters.html#a19e44a03729441c732e953a3ca01bc3f',1,'input_parameters']]],
  ['p2',['p2',['../structinput__parameters.html#acb0783d0bc4681f5aab137eec42eed08',1,'input_parameters']]],
  ['peasant',['peasant',['../structline.html#a89b63cb266efa1ebcb62489dfecc04e9',1,'line']]],
  ['player_5fnumber',['player_number',['../engine_8h.html#a230bf1ce6f1480f9fddb4577d1742f4f',1,'engine.h']]],
  ['previous',['previous',['../structline.html#abb721ad888ffdb866817db5b5afc033d',1,'line']]],
  ['previous_5fline',['previous_line',['../structlist__of__lines.html#a483118b9208361c9abaadd6c31c01b4f',1,'list_of_lines']]]
];
