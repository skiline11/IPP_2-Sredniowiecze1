var searchData=
[
  ['map_5fsize',['map_size',['../structlist__of__lines.html#a422664f6b1fecd50b43a0732624c3686',1,'list_of_lines']]],
  ['max_5fnumber_5fof_5fturns',['max_number_of_turns',['../structlist__of__lines.html#a978838f8a1d0131c1273c2976d3e7bb8',1,'list_of_lines']]]
];
