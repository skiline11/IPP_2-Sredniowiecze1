var searchData=
[
  ['end_5fgame',['end_game',['../engine_8h.html#a4202fa5c5191c7e387d7570da6c8cd8c',1,'engine.c']]],
  ['end_5fturn',['end_turn',['../engine_8h.html#a6c355efb3996f6ddcc16c27d0224bfb0',1,'engine.c']]],
  ['engine_2eh',['engine.h',['../engine_8h.html',1,'']]]
];
